package com.bhavesh.symsin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class RegisterActivity extends AppCompatActivity {

    TextView btnlogin;

    private EditText txtinputname,txtemail,txtpass,txtconfpass;
    Button btnregister;
    private FirebaseAuth mAuth;
    private ProgressDialog mLoadingBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        btnlogin = findViewById(R.id.txtalreadyaccount);
        txtinputname = findViewById(R.id.txtusername);
        txtemail = findViewById(R.id.txtlemail);
        txtpass = findViewById(R.id.txtpass);
        txtconfpass = findViewById(R.id.txtconfpass);

        btnregister = findViewById(R.id.btnregister);

        mAuth = FirebaseAuth.getInstance();
        mLoadingBar = new ProgressDialog(RegisterActivity.this);

        btnregister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkCredentials();
            }
        });




        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
            }
        });
    }

    private void checkCredentials() {

        String username = txtinputname.getText().toString();
        String email = txtemail.getText().toString();
        String pass = txtpass.getText().toString();
        String confirmpass = txtconfpass.getText().toString();
        
        if (username.isEmpty() || username.length()<7)
        {
            showError(txtinputname, "Your username is not valid!");
        }
        else if (email.isEmpty() || !email.contains("@"))
        {
            showError(txtemail, "Email is not valid");
        }
        else if (pass.isEmpty() || pass.length()<8)
        {
            showError(txtpass, "Password must be 8 Character");
        }
        else if (confirmpass.isEmpty() || !confirmpass.equals(pass))
        {
            showError(txtconfpass, "Password not matched");
        }
        else
        {
            mLoadingBar.setTitle("Registration");
            mLoadingBar.setMessage("Please Wait, While Check Your Credentials");
            mLoadingBar.setCanceledOnTouchOutside(false);
            mLoadingBar.show();

            mAuth.createUserWithEmailAndPassword(email, pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful())
                    {
                        Toast.makeText(RegisterActivity.this, "Successfully Registration", Toast.LENGTH_SHORT).show();

                        mLoadingBar.dismiss();

                        Intent intent =new Intent(RegisterActivity.this,MainActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);
                    }
                    else
                    {
                        Toast.makeText(RegisterActivity.this, task.getException().toString(),Toast.LENGTH_SHORT).show();
                    }

                }
            });

        }

    }

    private void showError(EditText input, String s) {
        input.setError(s);
        input.requestFocus();


    }
}
