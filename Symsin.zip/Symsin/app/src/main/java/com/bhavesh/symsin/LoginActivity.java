package com.bhavesh.symsin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class LoginActivity extends AppCompatActivity {

    TextView btnsignup;

    EditText txtinputname, txtlpass;
    Button btnlogin;
    private FirebaseAuth mAuth;
    ProgressDialog mLoadingBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        btnsignup = findViewById(R.id.txtsignup);
        txtinputname = findViewById(R.id.txtloginemail);
        txtlpass = findViewById(R.id.txtlpass);

        btnlogin = findViewById(R.id.btnlogin);

        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkCredentials();
            }
        });

        mAuth = FirebaseAuth.getInstance();
        mLoadingBar = new ProgressDialog(LoginActivity.this);


        btnsignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginActivity.this, RegisterActivity.class));
            }
        });
    }

    private void checkCredentials() {

        String username = txtinputname.getText().toString();
        String pass = txtlpass.getText().toString();

        if (username.isEmpty() || username.length() < 7) {
            showError(txtinputname, "Your username is not valid!");
        } else if (username.isEmpty() || !username.contains("@")) {
            showError(txtinputname, "Email is not valid");
        } else if (pass.isEmpty() || pass.length() < 8) {
            showError(txtlpass, "Password must be 8 Character");
        } else
            {
                mLoadingBar.setTitle("Login");
                mLoadingBar.setMessage("Please Wait, While Check Your Credentials");
                mLoadingBar.setCanceledOnTouchOutside(false);
                mLoadingBar.show();

                mAuth.signInWithEmailAndPassword(username, pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful())
                        {
                            Toast.makeText(LoginActivity.this, "Successfully Login", Toast.LENGTH_SHORT).show();
                            mLoadingBar.dismiss();
                            Intent intent =new Intent(LoginActivity.this,MainActivity.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent);

                        }
                    }
                });
        }

    }

    private void showError(EditText input, String s) {
        input.setError(s);
        input.requestFocus();

    }
}